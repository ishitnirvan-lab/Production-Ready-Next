/** @type {import('next').NextConfig} */
const nextConfig = {
  distDir: ".next-friendship",
  images: {
    formats: ["image/avif", "image/webp"]
  }
};

export default nextConfig;
