# Friendship Day Experience

A premium mobile-first interactive Friendship Day gift website built with Next.js, TypeScript, Tailwind CSS, Framer Motion, GSAP, Lenis, React Icons, and Canvas Confetti.

## Run Locally

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Customize

- Photos are in `public/memories/`.
- Add background music at `public/music/song.mp3`.
- Edit memories, appreciation cards, quiz questions, chat messages, and the letter in `components/FriendshipExperience.tsx`.

## Deploy

This project is ready for Vercel. Upload the project folder or connect it to a Git repository, then deploy with the default Next.js settings.
