import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      fontFamily: {
        display: ["var(--font-playfair)", "serif"],
        body: ["var(--font-poppins)", "sans-serif"],
        script: ["var(--font-dancing)", "cursive"]
      },
      colors: {
        roseglass: "#fff5f8",
        ink: "#352234",
        blush: "#f7abc6",
        lavender: "#c9b8ff",
        cream: "#fff6df",
        gilt: "#c7984c"
      },
      boxShadow: {
        glow: "0 18px 70px rgba(229, 106, 151, 0.24)",
        paper: "0 18px 45px rgba(93, 57, 78, 0.18)"
      },
      backgroundImage: {
        silk: "radial-gradient(circle at 20% 20%, rgba(255,255,255,.85), transparent 24%), radial-gradient(circle at 82% 12%, rgba(201,184,255,.45), transparent 22%), linear-gradient(135deg, #fff8ee 0%, #ffe8f1 48%, #f0e9ff 100%)"
      }
    }
  },
  plugins: []
};

export default config;
