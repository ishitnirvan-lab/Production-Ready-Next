import FriendshipExperience from "@/components/FriendshipExperience";

export default function Home() {
  return <FriendshipExperience />;
}
