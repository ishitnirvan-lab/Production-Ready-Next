import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Happy Friendship Day",
  description: "A premium interactive Friendship Day memory experience."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
