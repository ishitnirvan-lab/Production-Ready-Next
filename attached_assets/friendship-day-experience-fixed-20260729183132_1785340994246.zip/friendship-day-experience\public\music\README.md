Place your background music at:

song.mp3

The app already points to /music/song.mp3 and starts it after the first tap, click, or keyboard interaction.
